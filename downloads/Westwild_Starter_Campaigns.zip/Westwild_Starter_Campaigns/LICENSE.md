# Westwild: licensing at a glance

Westwild is **free to play, download, read and enjoy**. If you want to **make money** with it, you need to **request a license**.

Westwild is **free and source-available**. It is not "open source" in the strict sense, because commercial use is reserved.

| Part | License | Free for | Needs a license for |
|---|---|---|---|
| Code (launcher, builders, VTT, decks) | PolyForm Noncommercial 1.0.0 (`licenses/PolyForm-Noncommercial-1.0.0.md`) | Personal, hobby, educational and other noncommercial use; modifying and sharing for free | Any commercial use |
| Rules text | CC BY-NC-SA 4.0 (`licenses/CC-BY-NC-SA-4.0.txt`) | Playing, adapting, sharing for free with credit, under the same terms | Selling or monetizing it or anything built on it |
| Setting, lore, the Gazette, characters | All rights reserved, Anthony "Othello" Merriweather | Playing the game at the table; reading | Anything else: ask |
| Art | Not licensed under any of the above; credited artists keep their rights | Seeing it in place | Reusing it: ask the artist or owner |

## What stays free
Home games. Online games with friends. Streaming or recording your own play. Sharing free copies. Writing free fan material under the same terms. Fixing bugs and sending improvements.

## What needs a license ("commercial use")
Selling the game, a copy, a derivative, or a module or adventure built on it. Running it as a paid hosted service. Building a paid product on the code. Printing it for sale. Using it to make an app or a game you charge for.

## Paid game-running
Running a paid game session is a small-scale commercial use. Ask, and a free small-scale license is granted on request, so there is a record and no trouble.

## How to ask
Email support@wordblocklabs.com with what you plan to make and how you will charge for it. Terms are agreed case by case in writing.

## Credit
"Westwild by Anthony 'Othello' Merriweather. Pixel map by Michelle (mich-spich.carrd.co). Proofread with Grammarly. Rules written and playtested in Foundry VTT with online dice rollers."

*This page is a plain-English summary. The full license texts (PolyForm Noncommercial 1.0.0 and CC BY-NC-SA 4.0) are included in the download, and if this summary and those texts ever differ, the full texts control. This is not legal advice.*
